'use client'

import { motion } from 'framer-motion'

interface WorkshopCardProps {
  workshop: {
    id: number
    title: string
    description: string
    date: string
    location: string
    capacity: number
    enrolled: number
  }
  onRegister?: () => void
  isRegistered?: boolean
}

export default function WorkshopCard({ workshop, onRegister, isRegistered = false }: WorkshopCardProps) {
  const availability = workshop.capacity - workshop.enrolled
  const isFull = availability === 0

  return (
    <motion.div
      className="card bg-white dark:bg-gray-800 hover:shadow-2xl transition-all"
      whileHover={{ scale: 1.02 }}
      role="article"
      aria-labelledby={`workshop-${workshop.id}-title`}
    >
      <h3 id={`workshop-${workshop.id}-title`} className="text-xl font-bold mb-2 text-gray-900 dark:text-white">
        {workshop.title}
      </h3>
      <p className="text-gray-600 dark:text-gray-300 mb-4 text-lg leading-relaxed">{workshop.description}</p>
      <div className="space-y-2 mb-4 text-base">
        <div className="flex items-center text-gray-700 dark:text-gray-300">
          <span className="font-semibold mr-2">Date:</span>
          {new Date(workshop.date).toLocaleDateString()}
        </div>
        <div className="flex items-center text-gray-700 dark:text-gray-300">
          <span className="font-semibold mr-2">Location:</span>
          {workshop.location}
        </div>
        <div className="flex items-center text-gray-700 dark:text-gray-300">
          <span className="font-semibold mr-2">Spots:</span>
          {availability} available ({workshop.enrolled}/{workshop.capacity})
        </div>
      </div>
      <button
        onClick={onRegister}
        className={`w-full py-3 rounded-lg font-semibold transition-all text-lg focus:outline-none focus:ring-4 focus:ring-primary-500/50 ${
          isRegistered
            ? 'bg-green-600 text-white cursor-default'
            : isFull
            ? 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'
            : 'btn-primary hover:scale-105'
        }`}
        disabled={isFull || isRegistered}
        aria-label={isRegistered ? 'Already registered' : isFull ? 'Workshop is full' : `Register for ${workshop.title}`}
      >
        {isRegistered ? 'Registered ✓' : isFull ? 'Full' : 'Register Now'}
      </button>
    </motion.div>
  )
}

