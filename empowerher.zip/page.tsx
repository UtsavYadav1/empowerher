'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import ProtectedRoute from '@/components/ProtectedRoute'
import { CardSkeleton } from '@/components/LoadingSkeleton'
import { getCurrentUser } from '@/utils/auth'

interface ForumPost {
  id: number
  title: string
  author: string
  content: string
  replies: Array<{
    id: number
    author: string
    content: string
    createdAt: string
  }>
  createdAt: string
}

export default function ForumPage() {
  const [posts, setPosts] = useState<ForumPost[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [newPost, setNewPost] = useState({ title: '', content: '' })
  const [selectedPost, setSelectedPost] = useState<ForumPost | null>(null)
  const [comment, setComment] = useState('')
  const user = getCurrentUser()

  useEffect(() => {
    fetchPosts()
  }, [])

  const fetchPosts = async () => {
    try {
      const response = await fetch('/api/mock/forum')
      const data = await response.json()
      if (data.success) {
        setPosts(data.data)
      }
    } catch (error) {
      console.error('Error fetching posts:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch('/api/mock/forum', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newPost,
          author: user?.name || 'Anonymous',
        }),
      })
      const data = await response.json()
      if (data.success) {
        setPosts([data.data, ...posts])
        setNewPost({ title: '', content: '' })
        setShowForm(false)
      }
    } catch (error) {
      console.error('Error creating post:', error)
    }
  }

  const handleAddComment = async (postId: number) => {
    if (!comment.trim()) return
    try {
      const response = await fetch('/api/mock/forum', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          postId,
          author: user?.name || 'Anonymous',
          content: comment,
        }),
      })
      const data = await response.json()
      if (data.success) {
        setPosts(posts.map(p => p.id === postId ? data.data : p))
        setComment('')
        setSelectedPost(null)
      }
    } catch (error) {
      console.error('Error adding comment:', error)
    }
  }

  if (loading) {
    return (
      <ProtectedRoute requireRole={true}>
        <div className="min-h-screen py-20 container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map(i => <CardSkeleton key={i} />)}
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute requireRole={true}>
      <div className="min-h-screen py-20 container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-4xl font-bold">Community Forum</h1>
            <button
              onClick={() => setShowForm(!showForm)}
              className="btn-primary"
            >
              {showForm ? 'Cancel' : 'New Post'}
            </button>
          </div>

          {showForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="card mb-6"
            >
              <h2 className="text-2xl font-bold mb-4">Create New Post</h2>
              <form onSubmit={handleCreatePost} className="space-y-4">
                <input
                  type="text"
                  placeholder="Post Title"
                  value={newPost.title}
                  onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                  className="w-full px-4 py-2 border rounded-lg"
                  required
                />
                <textarea
                  placeholder="Post Content"
                  value={newPost.content}
                  onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                  rows={4}
                  className="w-full px-4 py-2 border rounded-lg"
                  required
                />
                <button type="submit" className="btn-primary">
                  Post
                </button>
              </form>
            </motion.div>
          )}

          <div className="space-y-6">
            {posts.map((post) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="card"
              >
                <h3 className="text-xl font-bold mb-2">{post.title}</h3>
                <p className="text-gray-600 mb-2">{post.content}</p>
                <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
                  <span>By {post.author}</span>
                  <span>{new Date(post.createdAt).toLocaleDateString()}</span>
                </div>
                <div className="border-t pt-4">
                  <button
                    onClick={() => setSelectedPost(post.id === selectedPost?.id ? null : post)}
                    className="text-primary-600 hover:underline mb-4"
                  >
                    {post.replies.length} {post.replies.length === 1 ? 'Reply' : 'Replies'}
                  </button>
                  {selectedPost?.id === post.id && (
                    <div className="space-y-4 mt-4">
                      {post.replies.map((reply) => (
                        <div key={reply.id} className="pl-4 border-l-2 border-gray-200">
                          <p className="font-semibold">{reply.author}</p>
                          <p className="text-gray-600">{reply.content}</p>
                          <p className="text-xs text-gray-500">{new Date(reply.createdAt).toLocaleDateString()}</p>
                        </div>
                      ))}
                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Add a comment..."
                          value={comment}
                          onChange={(e) => setComment(e.target.value)}
                          className="flex-1 px-4 py-2 border rounded-lg"
                        />
                        <button
                          onClick={() => handleAddComment(post.id)}
                          className="btn-primary"
                        >
                          Comment
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </ProtectedRoute>
  )
}

