'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import ProtectedRoute from '@/components/ProtectedRoute'
import { CardSkeleton } from '@/components/LoadingSkeleton'
import { FaExternalLinkAlt, FaRupeeSign } from 'react-icons/fa'

interface FinanceScheme {
  id: number
  title: string
  description: string
  amount: string
  interestRate: string
  eligibility: string
  applyUrl: string
  deadline: string | null
  category: string
}

export default function FinancePage() {
  const [schemes, setSchemes] = useState<FinanceScheme[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchSchemes()
  }, [])

  const fetchSchemes = async () => {
    try {
      const response = await fetch('/api/mock/finance')
      const data = await response.json()
      if (data.success) {
        setSchemes(data.data)
      }
    } catch (error) {
      console.error('Error fetching finance schemes:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <ProtectedRoute requireRole={true}>
        <div className="min-h-screen py-20 container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map(i => <CardSkeleton key={i} />)}
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute requireRole={true}>
      <div className="min-h-screen py-20 container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-4xl font-bold mb-8">Micro-Finance Guidance</h1>
          <p className="text-gray-600 mb-8">
            Explore government loan schemes and financial assistance programs for women entrepreneurs
          </p>

          <div className="grid md:grid-cols-2 gap-6">
            {schemes.map((scheme) => (
              <motion.div
                key={scheme.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="card hover:shadow-xl transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-2xl font-bold">{scheme.title}</h3>
                  <span className="px-3 py-1 bg-primary-100 text-primary-600 rounded text-sm">
                    {scheme.category}
                  </span>
                </div>
                <p className="text-gray-600 mb-4">{scheme.description}</p>
                
                <div className="space-y-3 mb-4">
                  <div className="flex items-center gap-2">
                    <FaRupeeSign className="text-green-600" />
                    <span className="font-semibold">Loan Amount:</span>
                    <span className="text-green-600 font-bold">{scheme.amount}</span>
                  </div>
                  <div>
                    <span className="font-semibold">Interest Rate:</span>
                    <span className="ml-2 text-primary-600 font-bold">{scheme.interestRate}</span>
                  </div>
                  <div>
                    <span className="font-semibold">Eligibility:</span>
                    <p className="text-sm text-gray-600 mt-1">{scheme.eligibility}</p>
                  </div>
                </div>

                <a
                  href={scheme.applyUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary w-full flex items-center justify-center gap-2"
                >
                  Apply Now
                  <FaExternalLinkAlt />
                </a>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </ProtectedRoute>
  )
}

