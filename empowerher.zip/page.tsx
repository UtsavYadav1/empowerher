'use client'

import Link from 'next/link'
import { motion, useScroll, useTransform } from 'framer-motion'
import { useState, useEffect, useRef } from 'react'
import Image from 'next/image'
import CountUp from 'react-countup'
import { FaUsers, FaGraduationCap, FaArrowRight } from 'react-icons/fa'

export default function Home() {
  const [isVisible, setIsVisible] = useState(false)
  const heroRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ['start start', 'end start'],
  })
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '50%'])
  const opacity = useTransform(scrollYProgress, [0, 1], [1, 0])

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <div className="min-h-screen" role="main">
      {/* Hero Section */}
      <section 
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        aria-label="Hero section"
      >
        {/* Background Image with Parallax */}
        <motion.div
          style={{ y, opacity }}
          className="absolute inset-0 z-0"
        >
          <div className="relative w-full h-full">
            <Image
              src="/images/hero.jpg"
              alt="EmpowerHer team and community"
              fill
              className="object-cover"
              priority
              sizes="100vw"
              aria-hidden="true"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-primary-900/80 to-primary-700/60" />
          </div>
        </motion.div>

        {/* Hero Content */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto"
        >
          <motion.h1
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="text-5xl md:text-7xl font-bold mb-6 text-shadow-lg"
          >
            EmpowerHer
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto leading-relaxed"
          >
            Empowering women and girls with education, business tools, and social impact
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link 
              href="/register" 
              className="btn-primary bg-white text-primary-600 hover:bg-gray-100 text-lg px-8 py-4 rounded-lg font-semibold transition-all hover:scale-105 focus:outline-none focus:ring-4 focus:ring-white/50"
              aria-label="Get started with EmpowerHer"
            >
              Get Started
            </Link>
            <Link 
              href="/about" 
              className="btn-secondary bg-transparent border-2 border-white text-white hover:bg-white hover:text-primary-600 text-lg px-8 py-4 rounded-lg font-semibold transition-all hover:scale-105 focus:outline-none focus:ring-4 focus:ring-white/50"
              aria-label="Learn more about EmpowerHer"
            >
              Learn More
            </Link>
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-6 h-10 border-2 border-white rounded-full flex justify-center"
            aria-hidden="true"
          >
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-1 h-3 bg-white rounded-full mt-2"
            />
          </motion.div>
        </motion.div>
      </section>

      {/* Impact Counters Section */}
      <section className="py-20 bg-gradient-to-br from-primary-50 to-primary-100 dark:from-gray-900 dark:to-gray-800" aria-label="Impact statistics">
        <div className="container mx-auto px-4">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-5xl font-bold text-center mb-12 text-gray-900 dark:text-white"
          >
            Our Impact
          </motion.h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="card text-center bg-white dark:bg-gray-800 hover:shadow-2xl transition-shadow"
            >
              <FaUsers className="text-5xl text-primary-600 dark:text-primary-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2 text-gray-900 dark:text-white">Women Empowered</h3>
              {isVisible && (
                <p className="text-5xl font-bold text-primary-600 dark:text-primary-400">
                  <CountUp end={1250} duration={2.5} separator="," />+
                </p>
              )}
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="card text-center bg-white dark:bg-gray-800 hover:shadow-2xl transition-shadow"
            >
              <FaGraduationCap className="text-5xl text-primary-600 dark:text-primary-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2 text-gray-900 dark:text-white">Girls Educated</h3>
              {isVisible && (
                <p className="text-5xl font-bold text-primary-600 dark:text-primary-400">
                  <CountUp end={3200} duration={2.5} separator="," />+
                </p>
              )}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 container mx-auto px-4" aria-label="Platform features">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-4xl md:text-5xl font-bold text-center mb-12 text-gray-900 dark:text-white"
        >
          Our Platform
        </motion.h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="card text-center bg-white dark:bg-gray-800 hover:shadow-2xl transition-all hover:scale-105"
          >
            <h3 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">For Girls</h3>
            <p className="text-gray-600 dark:text-gray-300 text-lg mb-6 leading-relaxed">
              Access educational resources, mentorship programs, and skill development courses designed for young minds.
            </p>
            <Link
              href="/girls/dashboard"
              className="inline-flex items-center gap-2 text-primary-600 dark:text-primary-400 font-semibold hover:gap-4 transition-all text-lg"
              aria-label="Explore Girls Section"
            >
              Explore Girls Section <FaArrowRight />
            </Link>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="card text-center bg-white dark:bg-gray-800 hover:shadow-2xl transition-all hover:scale-105"
          >
            <h3 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">For Women</h3>
            <p className="text-gray-600 dark:text-gray-300 text-lg mb-6 leading-relaxed">
              Business tools, networking opportunities, and professional development resources to advance your career.
            </p>
            <Link
              href="/women/dashboard"
              className="inline-flex items-center gap-2 text-primary-600 dark:text-primary-400 font-semibold hover:gap-4 transition-all text-lg"
              aria-label="Explore Women Section"
            >
              Explore Women Section <FaArrowRight />
            </Link>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="card text-center bg-white dark:bg-gray-800 hover:shadow-2xl transition-all hover:scale-105"
          >
            <h3 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">For Customers</h3>
            <p className="text-gray-600 dark:text-gray-300 text-lg mb-6 leading-relaxed">
              Support women-owned businesses by purchasing products and services that make a difference.
            </p>
            <Link
              href="/customer/products"
              className="inline-flex items-center gap-2 text-primary-600 dark:text-primary-400 font-semibold hover:gap-4 transition-all text-lg"
              aria-label="Browse Products"
            >
              Browse Products <FaArrowRight />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
