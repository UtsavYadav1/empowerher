'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import ProtectedRoute from '@/components/ProtectedRoute'
import { CardSkeleton } from '@/components/LoadingSkeleton'
import { FaCalendar, FaBell } from 'react-icons/fa'

interface Event {
  id: number
  title: string
  description: string
  date: string
  type: string
  category: string
  reminderSet: boolean
}

export default function EventsPage() {
  const [events, setEvents] = useState<Event[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState<string>('all')

  useEffect(() => {
    fetchEvents()
  }, [filter])

  const fetchEvents = async () => {
    try {
      const url = filter !== 'all' ? `/api/mock/events?type=${filter}` : '/api/mock/events'
      const response = await fetch(url)
      const data = await response.json()
      if (data.success) {
        setEvents(data.data)
      }
    } catch (error) {
      console.error('Error fetching events:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSetReminder = async (eventId: number, reminderSet: boolean) => {
    try {
      const response = await fetch('/api/mock/events', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventId, reminderSet: !reminderSet }),
      })
      const data = await response.json()
      if (data.success) {
        setEvents(events.map(e => e.id === eventId ? data.data : e))
      }
    } catch (error) {
      console.error('Error setting reminder:', error)
    }
  }

  const getDaysUntil = (dateString: string) => {
    const days = Math.ceil((new Date(dateString).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
    return days > 0 ? days : 0
  }

  if (loading) {
    return (
      <ProtectedRoute requireRole={true}>
        <div className="min-h-screen py-20 container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map(i => <CardSkeleton key={i} />)}
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute requireRole={true}>
      <div className="min-h-screen py-20 container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-4xl font-bold mb-8">Event Calendar</h1>
          
          <div className="flex gap-4 mb-6">
            {['all', 'scholarship', 'workshop', 'session'].map((type) => (
              <button
                key={type}
                onClick={() => setFilter(type)}
                className={`px-4 py-2 rounded-lg ${
                  filter === type
                    ? 'bg-primary-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </button>
            ))}
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.map((event) => {
              const daysUntil = getDaysUntil(event.date)
              return (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="card"
                >
                  <div className="flex items-start justify-between mb-4">
                    <FaCalendar className="text-primary-600 text-2xl" />
                    <span className="px-2 py-1 bg-primary-100 text-primary-600 rounded text-sm">
                      {event.type}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{event.title}</h3>
                  <p className="text-gray-600 mb-4">{event.description}</p>
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-500">
                        {new Date(event.date).toLocaleDateString()}
                      </p>
                      <p className="text-sm font-semibold text-primary-600">
                        {daysUntil === 0 ? 'Today' : `${daysUntil} days left`}
                      </p>
                    </div>
                    <button
                      onClick={() => handleSetReminder(event.id, event.reminderSet)}
                      className={`p-2 rounded-lg ${
                        event.reminderSet
                          ? 'bg-primary-600 text-white'
                          : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                      }`}
                      title={event.reminderSet ? 'Reminder Set' : 'Set Reminder'}
                    >
                      <FaBell />
                    </button>
                  </div>
                </motion.div>
              )
            })}
          </div>
        </motion.div>
      </div>
    </ProtectedRoute>
  )
}

