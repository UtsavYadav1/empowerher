'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import CourseCard from '@/components/CourseCard'
import ProgressChart from '@/components/ProgressChart'
import ProtectedRoute from '@/components/ProtectedRoute'
import { getCurrentUser } from '@/utils/auth'
import { generateCertificate } from '@/utils/certificate'
import { FaGraduationCap, FaBriefcase, FaBook, FaUserFriends, FaChartLine, FaComments, FaCalendar, FaCertificate } from 'react-icons/fa'

function GirlsDashboardContent() {
  const user = getCurrentUser()
  const [showCertificateModal, setShowCertificateModal] = useState(false)
  const [selectedCourse, setSelectedCourse] = useState('')

  const courses = [
    {
      id: 1,
      title: 'Introduction to Coding',
      description: 'Learn the basics of programming',
      category: 'Technology',
      progress: 45,
    },
    {
      id: 2,
      title: 'Creative Writing',
      description: 'Express yourself through writing',
      category: 'Arts',
      progress: 100,
    },
    {
      id: 3,
      title: 'Public Speaking',
      description: 'Build confidence in speaking',
      category: 'Communication',
      progress: 30,
    },
  ]

  const handleCompleteCourse = (courseTitle: string) => {
    setSelectedCourse(courseTitle)
    setShowCertificateModal(true)
  }

  const handleGenerateCertificate = () => {
    if (user && selectedCourse) {
      generateCertificate(user.name, selectedCourse)
      setShowCertificateModal(false)
    }
  }

  return (
    <div className="min-h-screen py-20 container mx-auto px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-bold mb-8">Girls Dashboard</h1>
        
        {/* Quick Links */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Link href="/girls/forum" className="card hover:shadow-xl transition-shadow text-center">
            <FaComments className="text-4xl text-primary-600 mx-auto mb-2" />
            <h3 className="font-bold">Community Forum</h3>
          </Link>
          <Link href="/girls/events" className="card hover:shadow-xl transition-shadow text-center">
            <FaCalendar className="text-4xl text-blue-600 mx-auto mb-2" />
            <h3 className="font-bold">Events</h3>
          </Link>
          <div className="card hover:shadow-xl transition-shadow text-center">
            <FaGraduationCap className="text-4xl text-green-600 mx-auto mb-2" />
            <h3 className="font-bold">Schemes</h3>
          </div>
          <div className="card hover:shadow-xl transition-shadow text-center">
            <FaBriefcase className="text-4xl text-purple-600 mx-auto mb-2" />
            <h3 className="font-bold">Career Guidance</h3>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <div className="card">
            <h3 className="text-xl font-bold mb-2">Enrolled Courses</h3>
            <p className="text-3xl font-bold text-primary-600">12</p>
          </div>
          <div className="card">
            <h3 className="text-xl font-bold mb-2">Completed</h3>
            <p className="text-3xl font-bold text-green-600">5</p>
          </div>
          <div className="card">
            <h3 className="text-xl font-bold mb-2">In Progress</h3>
            <p className="text-3xl font-bold text-blue-600">7</p>
          </div>
        </div>
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <div className="card">
            <h2 className="text-2xl font-bold mb-4">My Progress</h2>
            <ProgressChart />
          </div>
          <div className="card">
            <h2 className="text-2xl font-bold mb-4">Recent Courses</h2>
            <div className="space-y-4">
              {courses.map((course) => (
                <div key={course.id}>
                  <CourseCard course={course} />
                  {course.progress === 100 && (
                    <button
                      onClick={() => handleCompleteCourse(course.title)}
                      className="mt-2 btn-primary w-full"
                    >
                      <FaCertificate className="inline mr-2" />
                      Generate Certificate
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Certificate Modal */}
      {showCertificateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="card max-w-md"
          >
            <h2 className="text-2xl font-bold mb-4">Generate Certificate</h2>
            <p className="mb-4">Generate a certificate for completing: <strong>{selectedCourse}</strong></p>
            <div className="flex gap-4">
              <button onClick={handleGenerateCertificate} className="btn-primary flex-1">
                Generate & Download
              </button>
              <button onClick={() => setShowCertificateModal(false)} className="btn-secondary flex-1">
                Cancel
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  )
}

export default function GirlsDashboardPage() {
  return (
    <ProtectedRoute requireRole={true}>
      <GirlsDashboardContent />
    </ProtectedRoute>
  )
}

