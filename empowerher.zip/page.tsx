'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { useRouter } from 'next/navigation'
import ProtectedRoute from '@/components/ProtectedRoute'
import { CardSkeleton } from '@/components/LoadingSkeleton'
import { FaCreditCard, FaMoneyBillWave, FaUserTie } from 'react-icons/fa'

interface CartItem {
  id: number
  name: string
  price: number
  quantity: number
}

interface PaymentMethod {
  id: string
  name: string
  description: string
  icon: string
}

export default function CheckoutPage() {
  const router = useRouter()
  const [cart, setCart] = useState<CartItem[]>([])
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([])
  const [selectedMethod, setSelectedMethod] = useState<string>('')
  const [upiId, setUpiId] = useState('')
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(true)
  const [processing, setProcessing] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    loadCart()
    fetchPaymentMethods()
  }, [])

  const loadCart = () => {
    const savedCart = localStorage.getItem('cart')
    if (savedCart) {
      setCart(JSON.parse(savedCart))
    }
    setLoading(false)
  }

  const fetchPaymentMethods = async () => {
    try {
      const response = await fetch('/api/mock/payments')
      const data = await response.json()
      if (data.success) {
        setPaymentMethods(data.data.methods)
        setSelectedMethod(data.data.methods[0]?.id || '')
      }
    } catch (error) {
      console.error('Error fetching payment methods:', error)
    }
  }

  const handlePayment = async () => {
    if (!selectedMethod) {
      setError('Please select a payment method')
      return
    }

    if (selectedMethod === 'upi' && !upiId.trim()) {
      setError('Please enter your UPI ID')
      return
    }

    if (selectedMethod === 'cash_to_agent' && !phone.trim()) {
      setError('Please enter your phone number for agent contact')
      return
    }

    setProcessing(true)
    setError('')

    try {
      const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0) + 50
      const orderId = `ORD${Date.now()}`

      const response = await fetch('/api/mock/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: total,
          method: selectedMethod,
          orderId,
          upiId: selectedMethod === 'upi' ? upiId : undefined,
          phone: selectedMethod === 'cash_to_agent' ? phone : undefined,
        }),
      })

      const data = await response.json()

      if (data.success) {
        // Clear cart
        localStorage.removeItem('cart')
        // Redirect to success page
        router.push(`/customer/orders?success=true&txn=${data.data.transactionId}`)
      } else {
        setError(data.error || 'Payment failed. Please try again.')
        setProcessing(false)
      }
    } catch (error) {
      console.error('Error processing payment:', error)
      setError('An error occurred. Please try again.')
      setProcessing(false)
    }
  }

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const shipping = 50
  const grandTotal = total + shipping

  if (loading) {
    return (
      <ProtectedRoute requireRole={true}>
        <div className="min-h-screen py-20 container mx-auto px-4">
          <CardSkeleton />
        </div>
      </ProtectedRoute>
    )
  }

  if (cart.length === 0) {
    return (
      <ProtectedRoute requireRole={true}>
        <div className="min-h-screen py-20 container mx-auto px-4">
          <div className="card text-center py-12">
            <p className="text-gray-600 dark:text-gray-300 text-lg mb-4">Your cart is empty</p>
            <a href="/customer/products" className="btn-primary">
              Browse Products
            </a>
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute requireRole={true}>
      <div className="min-h-screen py-20 container mx-auto px-4" role="main">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-8 text-gray-900 dark:text-white">
            Checkout
          </h1>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Payment Methods */}
            <div className="space-y-6">
              <div className="card bg-white dark:bg-gray-800">
                <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">
                  Payment Method
                </h2>
                {error && (
                  <div className="mb-4 p-4 bg-red-100 dark:bg-red-900 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-300 rounded-lg text-lg" role="alert">
                    {error}
                  </div>
                )}

                <div className="space-y-4">
                  {paymentMethods.map((method) => (
                    <motion.div
                      key={method.id}
                      whileHover={{ scale: 1.02 }}
                      className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                        selectedMethod === method.id
                          ? 'border-primary-600 dark:border-primary-400 bg-primary-50 dark:bg-primary-900/20'
                          : 'border-gray-300 dark:border-gray-600 hover:border-primary-400'
                      }`}
                      onClick={() => setSelectedMethod(method.id)}
                      role="radio"
                      aria-checked={selectedMethod === method.id}
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          setSelectedMethod(method.id)
                        }
                      }}
                    >
                      <div className="flex items-start gap-4">
                        <div className="text-3xl">{method.icon}</div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <input
                              type="radio"
                              name="paymentMethod"
                              id={method.id}
                              checked={selectedMethod === method.id}
                              onChange={() => setSelectedMethod(method.id)}
                              className="w-5 h-5 text-primary-600"
                            />
                            <label
                              htmlFor={method.id}
                              className="text-xl font-bold text-gray-900 dark:text-white cursor-pointer"
                            >
                              {method.name}
                            </label>
                          </div>
                          <p className="text-gray-600 dark:text-gray-300 text-base">
                            {method.description}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Additional Fields */}
                {selectedMethod === 'upi' && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="mt-4"
                  >
                    <label htmlFor="upiId" className="block text-lg font-semibold mb-2 text-gray-900 dark:text-white">
                      UPI ID
                    </label>
                    <input
                      type="text"
                      id="upiId"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      placeholder="yourname@upi"
                      className="w-full px-4 py-3 text-lg border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-4 focus:ring-primary-500/50 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      required
                    />
                  </motion.div>
                )}

                {selectedMethod === 'cash_to_agent' && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="mt-4"
                  >
                    <label htmlFor="phone" className="block text-lg font-semibold mb-2 text-gray-900 dark:text-white">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 9876543210"
                      className="w-full px-4 py-3 text-lg border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-4 focus:ring-primary-500/50 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                      required
                    />
                    <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                      Our field agent will contact you for delivery and payment
                    </p>
                  </motion.div>
                )}
              </div>
            </div>

            {/* Order Summary */}
            <div className="space-y-6">
              <div className="card bg-white dark:bg-gray-800">
                <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">
                  Order Summary
                </h2>
                <div className="space-y-4 mb-6">
                  {cart.map((item) => (
                    <div key={item.id} className="flex justify-between items-center py-2 border-b border-gray-200 dark:border-gray-700">
                      <div>
                        <p className="font-semibold text-gray-900 dark:text-white text-lg">{item.name}</p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Qty: {item.quantity}</p>
                      </div>
                      <p className="font-bold text-lg text-gray-900 dark:text-white">₹{item.price * item.quantity}</p>
                    </div>
                  ))}
                </div>
                <div className="space-y-2 text-lg">
                  <div className="flex justify-between text-gray-700 dark:text-gray-300">
                    <span>Subtotal</span>
                    <span>₹{total}</span>
                  </div>
                  <div className="flex justify-between text-gray-700 dark:text-gray-300">
                    <span>Shipping</span>
                    <span>₹{shipping}</span>
                  </div>
                  <div className="border-t border-gray-300 dark:border-gray-600 pt-2 flex justify-between font-bold text-2xl text-primary-600 dark:text-primary-400">
                    <span>Total</span>
                    <span>₹{grandTotal}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={handlePayment}
                disabled={processing || !selectedMethod}
                className="btn-primary w-full text-lg py-4 disabled:opacity-50 disabled:cursor-not-allowed"
                aria-label="Complete payment"
              >
                {processing ? 'Processing...' : `Pay ₹${grandTotal}`}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </ProtectedRoute>
  )
}

