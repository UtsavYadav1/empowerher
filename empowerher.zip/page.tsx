'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Image from 'next/image'
import Lightbox from '@/components/Lightbox'

const galleryImages = [
  '/images/hero.jpg',
  '/images/team.jpg',
  '/images/workshop.jpg',
  '/images/community.jpg',
  '/images/outreach.jpg',
  '/images/school.jpg',
  '/images/hero.jpg',
  '/images/team.jpg',
  '/images/workshop.jpg',
]

const galleryItems = [
  { id: 1, title: 'Workshop 2024', description: 'Empowerment workshop for young women', image: '/images/workshop.jpg' },
  { id: 2, title: 'Community Event', description: 'Building stronger communities together', image: '/images/community.jpg' },
  { id: 3, title: 'Rural Outreach', description: 'Connecting with rural communities', image: '/images/outreach.jpg' },
  { id: 4, title: 'School Visit', description: 'Educational programs in schools', image: '/images/school.jpg' },
  { id: 5, title: 'Team Gathering', description: 'Our dedicated team members', image: '/images/team.jpg' },
  { id: 6, title: 'Workshop Session', description: 'Hands-on learning experiences', image: '/images/workshop.jpg' },
  { id: 7, title: 'Community Impact', description: 'Making a difference together', image: '/images/community.jpg' },
  { id: 8, title: 'Education Program', description: 'Empowering through education', image: '/images/school.jpg' },
  { id: 9, title: 'Outreach Event', description: 'Reaching out to communities', image: '/images/outreach.jpg' },
]

export default function GalleryPage() {
  const [lightboxOpen, setLightboxOpen] = useState(false)
  const [lightboxIndex, setLightboxIndex] = useState(0)

  const openLightbox = (index: number) => {
    setLightboxIndex(index)
    setLightboxOpen(true)
  }

  return (
    <div className="min-h-screen py-20 container mx-auto px-4" role="main">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-12 text-center text-gray-900 dark:text-white">
          Gallery
        </h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" role="list">
          {galleryItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="card overflow-hidden cursor-pointer hover:shadow-2xl transition-all hover:scale-105"
              onClick={() => openLightbox(index)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  openLightbox(index)
                }
              }}
              tabIndex={0}
              role="listitem"
              aria-label={`View ${item.title} image`}
            >
              <div className="relative h-64 w-full">
                <Image
                  src={item.image}
                  alt={item.title}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 hover:opacity-100 transition-opacity" />
                <div className="absolute bottom-0 left-0 right-0 p-4 text-white opacity-0 hover:opacity-100 transition-opacity">
                  <h3 className="text-xl font-bold mb-1">{item.title}</h3>
                  <p className="text-sm">{item.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      <Lightbox
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        images={galleryItems.map(item => item.image)}
        currentIndex={lightboxIndex}
        onNavigate={setLightboxIndex}
      />
    </div>
  )
}
