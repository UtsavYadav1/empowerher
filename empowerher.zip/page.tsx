'use client'

import { motion } from 'framer-motion'
import ImageCarousel from '@/components/ImageCarousel'

const carouselItems = [
  {
    id: 1,
    image: '/images/hero.jpg',
    title: 'Our Team',
    description: 'Dedicated team members working together to empower women and girls',
  },
  {
    id: 2,
    image: '/images/team.jpg',
    title: 'Rural Outreach',
    description: 'Connecting with communities in rural areas to bring education and opportunities',
  },
  {
    id: 3,
    image: '/images/workshop.jpg',
    title: 'Workshops',
    description: 'Hands-on workshops teaching practical skills and knowledge',
  },
  {
    id: 4,
    image: '/images/community.jpg',
    title: 'Community Events',
    description: 'Building stronger communities through engagement and support',
  },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen py-20 container mx-auto px-4" role="main">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-6xl mx-auto"
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-8 text-center text-gray-900 dark:text-white">
          About EmpowerHer
        </h1>
        
        {/* Image Carousel */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-12"
        >
          <ImageCarousel items={carouselItems} />
        </motion.div>

        <div className="card mb-8 bg-white dark:bg-gray-800">
          <h2 className="text-3xl font-bold mb-4 text-gray-900 dark:text-white">Our Mission</h2>
          <p className="text-gray-700 dark:text-gray-300 leading-relaxed mb-4 text-lg">
            EmpowerHer is a comprehensive platform designed to empower women and girls at every stage of their journey. 
            We provide education, business tools, and opportunities for social impact that help create a more equitable world.
          </p>
          <p className="text-gray-700 dark:text-gray-300 leading-relaxed text-lg">
            Our platform serves four distinct user roles: Girls, Women, Customers, and Administrators, each with tailored 
            features and resources to support their unique needs and goals.
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="card bg-white dark:bg-gray-800 hover:shadow-2xl transition-shadow"
          >
            <h3 className="text-2xl font-bold mb-3 text-gray-900 dark:text-white">Education</h3>
            <p className="text-gray-600 dark:text-gray-300 text-lg leading-relaxed">
              Access courses, workshops, and mentorship programs designed to build skills and confidence.
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="card bg-white dark:bg-gray-800 hover:shadow-2xl transition-shadow"
          >
            <h3 className="text-2xl font-bold mb-3 text-gray-900 dark:text-white">Business Tools</h3>
            <p className="text-gray-600 dark:text-gray-300 text-lg leading-relaxed">
              Resources and tools to help women entrepreneurs start and grow their businesses.
            </p>
          </motion.div>
        </div>
      </motion.div>
    </div>
  )
}
