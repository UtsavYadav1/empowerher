'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import ProtectedRoute from '@/components/ProtectedRoute'
import { TableSkeleton } from '@/components/LoadingSkeleton'
import { FaStar } from 'react-icons/fa'

interface Order {
  id: number
  customerId: number
  items: any
  total: number
  status: string
  createdAt: string
}

export default function FeedbackPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [rating, setRating] = useState(5)
  const [feedback, setFeedback] = useState('')

  useEffect(() => {
    fetchOrders()
  }, [])

  const fetchOrders = async () => {
    try {
      const response = await fetch('/api/mock/users?role=customer')
      // For demo, we'll use mock orders
      const mockOrders: Order[] = [
        {
          id: 1,
          customerId: 1,
          items: JSON.stringify([{ productId: 1, quantity: 2, name: 'Spicy Mango Pickle' }]),
          total: 300,
          status: 'delivered',
          createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: 2,
          customerId: 2,
          items: JSON.stringify([{ productId: 7, quantity: 1, name: 'Handmade Diya Set' }]),
          total: 200,
          status: 'delivered',
          createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        },
      ]
      setOrders(mockOrders)
    } catch (error) {
      console.error('Error fetching orders:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmitFeedback = async (orderId: number) => {
    try {
      const response = await fetch(`/api/mock/orders/${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          buyerRating: rating,
          feedback,
        }),
      })
      const data = await response.json()
      if (data.success) {
        setOrders(orders.map(o => o.id === orderId ? { ...o, feedback: true } as any : o))
        setSelectedOrder(null)
        setRating(5)
        setFeedback('')
        alert('Feedback submitted successfully!')
      }
    } catch (error) {
      console.error('Error submitting feedback:', error)
    }
  }

  const getOrderItems = (items: any) => {
    try {
      const parsed = typeof items === 'string' ? JSON.parse(items) : items
      return Array.isArray(parsed) ? parsed : []
    } catch {
      return []
    }
  }

  if (loading) {
    return (
      <ProtectedRoute requireRole={true}>
        <div className="min-h-screen py-20 container mx-auto px-4">
          <TableSkeleton />
        </div>
      </ProtectedRoute>
    )
  }

  const deliveredOrders = orders.filter(o => o.status === 'delivered')

  return (
    <ProtectedRoute requireRole={true}>
      <div className="min-h-screen py-20 container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-4xl font-bold mb-8">Buyer Feedback</h1>
          <p className="text-gray-600 mb-8">Rate and provide feedback for buyers after order delivery</p>

          {deliveredOrders.length === 0 ? (
            <div className="card text-center py-12">
              <p className="text-gray-600">No delivered orders to provide feedback for yet.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {deliveredOrders.map((order) => {
                const items = getOrderItems(order.items)
                return (
                  <motion.div
                    key={order.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="card"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-xl font-bold">Order #{order.id}</h3>
                        <p className="text-sm text-gray-500">
                          Delivered on {new Date(order.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-primary-600">₹{order.total}</p>
                        <p className="text-sm text-gray-500">{items.length} item(s)</p>
                      </div>
                    </div>

                    <div className="mb-4">
                      <h4 className="font-semibold mb-2">Items:</h4>
                      <ul className="list-disc list-inside space-y-1">
                        {items.map((item: any, idx: number) => (
                          <li key={idx} className="text-gray-600">
                            {item.name || `Product ${item.productId}`} x {item.quantity}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <button
                      onClick={() => setSelectedOrder(order)}
                      className="btn-primary w-full"
                    >
                      Provide Feedback
                    </button>
                  </motion.div>
                )
              })}
            </div>
          )}

          {/* Feedback Modal */}
          {selectedOrder && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="card max-w-md w-full"
              >
                <h2 className="text-2xl font-bold mb-4">Rate Buyer - Order #{selectedOrder.id}</h2>
                
                <div className="mb-4">
                  <label className="block font-semibold mb-2">Rating</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => setRating(star)}
                        className={`text-3xl ${
                          star <= rating ? 'text-yellow-400' : 'text-gray-300'
                        }`}
                      >
                        <FaStar />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block font-semibold mb-2">Feedback</label>
                  <textarea
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    rows={4}
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder="Share your experience with this buyer..."
                  />
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => {
                      setSelectedOrder(null)
                      setRating(5)
                      setFeedback('')
                    }}
                    className="btn-secondary flex-1"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleSubmitFeedback(selectedOrder.id)}
                    className="btn-primary flex-1"
                  >
                    Submit Feedback
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </motion.div>
      </div>
    </ProtectedRoute>
  )
}

