'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import ProtectedRoute from '@/components/ProtectedRoute'
import { CardSkeleton } from '@/components/LoadingSkeleton'
import { FaCheckCircle, FaCircle, FaPlay } from 'react-icons/fa'

interface Tutorial {
  id: number
  title: string
  description: string
  videoUrl: string
  duration: string
  category: string
  watched: boolean
}

export default function TutorialsPage() {
  const [tutorials, setTutorials] = useState<Tutorial[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedTutorial, setSelectedTutorial] = useState<Tutorial | null>(null)
  const [filter, setFilter] = useState<string>('all')

  useEffect(() => {
    fetchTutorials()
  }, [filter])

  const fetchTutorials = async () => {
    try {
      const url = filter !== 'all' ? `/api/mock/tutorials?category=${filter}` : '/api/mock/tutorials'
      const response = await fetch(url)
      const data = await response.json()
      if (data.success) {
        setTutorials(data.data)
      }
    } catch (error) {
      console.error('Error fetching tutorials:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleMarkWatched = async (tutorialId: number, watched: boolean) => {
    try {
      const response = await fetch('/api/mock/tutorials', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tutorialId, watched: !watched }),
      })
      const data = await response.json()
      if (data.success) {
        setTutorials(tutorials.map(t => t.id === tutorialId ? data.data : t))
      }
    } catch (error) {
      console.error('Error marking tutorial:', error)
    }
  }

  if (loading) {
    return (
      <ProtectedRoute requireRole={true}>
        <div className="min-h-screen py-20 container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map(i => <CardSkeleton key={i} />)}
          </div>
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute requireRole={true}>
      <div className="min-h-screen py-20 container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-4xl font-bold mb-8">Skill Tutorials</h1>
          
          <div className="flex gap-4 mb-6">
            {['all', 'business', 'marketing', 'finance'].map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-4 py-2 rounded-lg ${
                  filter === cat
                    ? 'bg-primary-600 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {cat.charAt(0).toUpperCase() + cat.slice(1)}
              </button>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              {selectedTutorial ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="card"
                >
                  <button
                    onClick={() => setSelectedTutorial(null)}
                    className="mb-4 text-primary-600 hover:underline"
                  >
                    ← Back to Tutorials
                  </button>
                  <h2 className="text-2xl font-bold mb-4">{selectedTutorial.title}</h2>
                  <div className="aspect-video mb-4">
                    <iframe
                      src={selectedTutorial.videoUrl}
                      className="w-full h-full rounded-lg"
                      allowFullScreen
                      title={selectedTutorial.title}
                    />
                  </div>
                  <p className="text-gray-600 mb-4">{selectedTutorial.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Duration: {selectedTutorial.duration}</span>
                    <button
                      onClick={() => handleMarkWatched(selectedTutorial.id, selectedTutorial.watched)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                        selectedTutorial.watched
                          ? 'bg-green-100 text-green-700'
                          : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                      }`}
                    >
                      {selectedTutorial.watched ? (
                        <>
                          <FaCheckCircle /> Watched
                        </>
                      ) : (
                        <>
                          <FaCircle /> Mark as Watched
                        </>
                      )}
                    </button>
                  </div>
                </motion.div>
              ) : (
                <div className="space-y-4">
                  {tutorials.map((tutorial) => (
                    <motion.div
                      key={tutorial.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="card cursor-pointer hover:shadow-xl transition-shadow"
                      onClick={() => setSelectedTutorial(tutorial)}
                    >
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0">
                          <div className="w-32 h-20 bg-gray-200 rounded-lg flex items-center justify-center">
                            <FaPlay className="text-2xl text-gray-400" />
                          </div>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="text-xl font-bold mb-2">{tutorial.title}</h3>
                              <p className="text-gray-600 mb-2">{tutorial.description}</p>
                              <div className="flex items-center gap-4 text-sm text-gray-500">
                                <span>{tutorial.duration}</span>
                                <span className="px-2 py-1 bg-primary-100 text-primary-600 rounded">
                                  {tutorial.category}
                                </span>
                              </div>
                            </div>
                            {tutorial.watched && (
                              <FaCheckCircle className="text-green-600 text-xl" />
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
            <div className="card">
              <h3 className="text-xl font-bold mb-4">Progress</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span>Watched</span>
                    <span className="font-bold">
                      {tutorials.filter(t => t.watched).length} / {tutorials.length}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-primary-600 h-2 rounded-full"
                      style={{
                        width: `${(tutorials.filter(t => t.watched).length / tutorials.length) * 100}%`,
                      }}
                    />
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <h4 className="font-semibold mb-2">Categories</h4>
                  <div className="space-y-2">
                    {['business', 'marketing', 'finance'].map((cat) => {
                      const count = tutorials.filter(t => t.category === cat).length
                      const watched = tutorials.filter(t => t.category === cat && t.watched).length
                      return (
                        <div key={cat}>
                          <div className="flex justify-between text-sm">
                            <span>{cat}</span>
                            <span>{watched}/{count}</span>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </ProtectedRoute>
  )
}

