'use client'

import { useState, useRef } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import WorkshopCard from '@/components/WorkshopCard'

const workshops = [
  {
    id: 1,
    title: 'Leadership Skills for Young Women',
    description: 'Learn essential leadership skills and build confidence',
    date: '2024-03-15',
    location: 'Online',
    capacity: 50,
    enrolled: 32,
  },
  {
    id: 2,
    title: 'Entrepreneurship Basics',
    description: 'Introduction to starting your own business',
    date: '2024-03-20',
    location: 'Conference Center',
    capacity: 30,
    enrolled: 15,
  },
  {
    id: 3,
    title: 'Digital Marketing Masterclass',
    description: 'Master social media and digital marketing strategies',
    date: '2024-03-25',
    location: 'Online',
    capacity: 100,
    enrolled: 67,
  },
  {
    id: 4,
    title: 'Financial Literacy Workshop',
    description: 'Understanding money management and investments',
    date: '2024-04-01',
    location: 'Community Center',
    capacity: 40,
    enrolled: 28,
  },
  {
    id: 5,
    title: 'Handicraft Training',
    description: 'Learn traditional crafts and business skills',
    date: '2024-04-05',
    location: 'Workshop Hall',
    capacity: 25,
    enrolled: 20,
  },
  {
    id: 6,
    title: 'Self-Defense Training',
    description: 'Basic self-defense techniques for safety',
    date: '2024-04-10',
    location: 'Sports Complex',
    capacity: 35,
    enrolled: 30,
  },
]

export default function WorkshopsPage() {
  const [registered, setRegistered] = useState<number[]>([])
  
  const handleRegister = (id: number) => {
    setRegistered([...registered, id])
    alert('Successfully registered for workshop!')
  }

  return (
    <div className="min-h-screen py-20 container mx-auto px-4" role="main">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-12 text-center text-gray-900 dark:text-white">
          Workshops
        </h1>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" role="list">
          {workshops.map((workshop, index) => {
            const ref = useRef<HTMLDivElement>(null)
            const { scrollYProgress } = useScroll({
              target: ref,
              offset: ['start end', 'end start'],
            })
            const y = useTransform(scrollYProgress, [0, 1], [50, -50])
            const opacity = useTransform(scrollYProgress, [0, 0.5, 1], [0.5, 1, 0.5])

            return (
              <motion.div
                key={workshop.id}
                ref={ref}
                style={{ y, opacity }}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-100px' }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                role="listitem"
              >
                <WorkshopCard 
                  workshop={workshop} 
                  onRegister={() => handleRegister(workshop.id)}
                  isRegistered={registered.includes(workshop.id)}
                />
              </motion.div>
            )
          })}
        </div>
      </motion.div>
    </div>
  )
}
