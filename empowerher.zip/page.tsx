'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import ProductCard from '@/components/ProductCard'
import ProtectedRoute from '@/components/ProtectedRoute'
import { CardSkeleton } from '@/components/LoadingSkeleton'
import { FaShoppingBag, FaHistory, FaShoppingCart } from 'react-icons/fa'

function CustomerDashboardContent() {
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchProducts()
  }, [])

  const fetchProducts = async () => {
    try {
      const response = await fetch('/api/mock/products?limit=3')
      const data = await response.json()
      if (data.success) {
        setProducts(data.data.slice(0, 3))
      }
    } catch (error) {
      console.error('Error fetching products:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen py-20 container mx-auto px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-bold mb-8">Customer Dashboard</h1>
        
        {/* Quick Links */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Link href="/customer/products" className="card hover:shadow-xl transition-shadow text-center">
            <FaShoppingBag className="text-4xl text-primary-600 mx-auto mb-2" />
            <h3 className="font-bold">Browse Products</h3>
          </Link>
          <Link href="/customer/cart" className="card hover:shadow-xl transition-shadow text-center">
            <FaShoppingCart className="text-4xl text-blue-600 mx-auto mb-2" />
            <h3 className="font-bold">Shopping Cart</h3>
          </Link>
          <Link href="/customer/orders" className="card hover:shadow-xl transition-shadow text-center">
            <FaHistory className="text-4xl text-green-600 mx-auto mb-2" />
            <h3 className="font-bold">Order History</h3>
          </Link>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="card text-center">
            <h3 className="text-xl font-bold mb-2">Total Orders</h3>
            <p className="text-3xl font-bold text-primary-600">15</p>
          </div>
          <div className="card text-center">
            <h3 className="text-xl font-bold mb-2">Pending</h3>
            <p className="text-3xl font-bold text-yellow-600">3</p>
          </div>
          <div className="card text-center">
            <h3 className="text-xl font-bold mb-2">Completed</h3>
            <p className="text-3xl font-bold text-green-600">12</p>
          </div>
        </div>
        <h2 className="text-2xl font-bold mb-6">Featured Products</h2>
        {loading ? (
          <div className="grid md:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => <CardSkeleton key={i} />)}
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-6">
            {products.map((product) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <Link href={`/customer/products/${product.id}`}>
                  <ProductCard product={{
                    id: product.id,
                    name: product.title,
                    description: product.description,
                    price: product.price,
                    imageUrl: Array.isArray(product.images) ? product.images[0] : '/images/default.jpg',
                  }} />
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  )
}

export default function CustomerDashboardPage() {
  return (
    <ProtectedRoute requireRole={true}>
      <CustomerDashboardContent />
    </ProtectedRoute>
  )
}

