'use client'

import { motion } from 'framer-motion'
import { useState } from 'react'
import Link from 'next/link'
import BusinessChart from '@/components/BusinessChart'
import ProtectedRoute from '@/components/ProtectedRoute'
import { FaVideo, FaMoneyBillWave, FaComments, FaShoppingBag, FaBox, FaChartBar } from 'react-icons/fa'

function WomenDashboardContent() {
  const [stats] = useState({
    revenue: 12500,
    orders: 34,
    products: 12,
    customers: 89,
  })

  return (
    <div className="min-h-screen py-20 container mx-auto px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-bold mb-8">Women Dashboard</h1>
        
        {/* Quick Links */}
        <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          <Link href="/women/tutorials" className="card hover:shadow-xl transition-shadow text-center">
            <FaVideo className="text-3xl text-primary-600 mx-auto mb-2" />
            <h3 className="font-semibold text-sm">Tutorials</h3>
          </Link>
          <Link href="/women/finance" className="card hover:shadow-xl transition-shadow text-center">
            <FaMoneyBillWave className="text-3xl text-green-600 mx-auto mb-2" />
            <h3 className="font-semibold text-sm">Finance</h3>
          </Link>
          <Link href="/women/feedback" className="card hover:shadow-xl transition-shadow text-center">
            <FaComments className="text-3xl text-blue-600 mx-auto mb-2" />
            <h3 className="font-semibold text-sm">Feedback</h3>
          </Link>
          <div className="card hover:shadow-xl transition-shadow text-center">
            <FaShoppingBag className="text-3xl text-purple-600 mx-auto mb-2" />
            <h3 className="font-semibold text-sm">Sell</h3>
          </div>
          <div className="card hover:shadow-xl transition-shadow text-center">
            <FaBox className="text-3xl text-orange-600 mx-auto mb-2" />
            <h3 className="font-semibold text-sm">Orders</h3>
          </div>
          <div className="card hover:shadow-xl transition-shadow text-center">
            <FaChartBar className="text-3xl text-red-600 mx-auto mb-2" />
            <h3 className="font-semibold text-sm">Analytics</h3>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="card">
            <h3 className="text-lg font-semibold mb-2 text-gray-600">Revenue</h3>
            <p className="text-3xl font-bold text-primary-600">${stats.revenue.toLocaleString()}</p>
          </div>
          <div className="card">
            <h3 className="text-lg font-semibold mb-2 text-gray-600">Orders</h3>
            <p className="text-3xl font-bold text-blue-600">{stats.orders}</p>
          </div>
          <div className="card">
            <h3 className="text-lg font-semibold mb-2 text-gray-600">Products</h3>
            <p className="text-3xl font-bold text-green-600">{stats.products}</p>
          </div>
          <div className="card">
            <h3 className="text-lg font-semibold mb-2 text-gray-600">Customers</h3>
            <p className="text-3xl font-bold text-purple-600">{stats.customers}</p>
          </div>
        </div>
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="card">
            <h2 className="text-2xl font-bold mb-4">Business Analytics</h2>
            <BusinessChart />
          </div>
          <div className="card">
            <h2 className="text-2xl font-bold mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <button className="btn-primary w-full">Add New Product</button>
              <button className="btn-secondary w-full">View Orders</button>
              <button className="btn-secondary w-full">Manage Inventory</button>
              <button className="btn-secondary w-full">View Analytics</button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  )
}

export default function WomenDashboardPage() {
  return (
    <ProtectedRoute requireRole={true}>
      <WomenDashboardContent />
    </ProtectedRoute>
  )
}

