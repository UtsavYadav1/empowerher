'use client'

import { useState, useEffect } from 'react'
import { useSearchParams } from 'next/navigation'
import { motion } from 'framer-motion'
import ProtectedRoute from '@/components/ProtectedRoute'
import { TableSkeleton } from '@/components/LoadingSkeleton'
import { getCurrentUser } from '@/utils/auth'
import { FaCheckCircle } from 'react-icons/fa'

export default function OrdersPage() {
  const searchParams = useSearchParams()
  const [orders, setOrders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [showSuccess, setShowSuccess] = useState(false)
  const [transactionId, setTransactionId] = useState<string | null>(null)
  const user = getCurrentUser()

  useEffect(() => {
    const success = searchParams.get('success')
    const txn = searchParams.get('txn')
    if (success === 'true' && txn) {
      setShowSuccess(true)
      setTransactionId(txn)
      setTimeout(() => setShowSuccess(false), 5000)
    }
    fetchOrders()
  }, [searchParams])

  useEffect(() => {
    fetchOrders()
  }, [])

  const fetchOrders = async () => {
    try {
      // Fetch orders for current user
      // In real app, filter by userId
      const response = await fetch('/api/mock/products')
      // Mock orders for demo
      const mockOrders = [
        {
          id: 1,
          items: [{ name: 'Spicy Mango Pickle', quantity: 2, price: 150 }],
          total: 350,
          status: 'delivered',
          createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: 2,
          items: [{ name: 'Handmade Diya Set', quantity: 1, price: 200 }],
          total: 250,
          status: 'processing',
          createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        },
      ]
      setOrders(mockOrders)
    } catch (error) {
      console.error('Error fetching orders:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-green-100 text-green-700'
      case 'processing': return 'bg-yellow-100 text-yellow-700'
      case 'shipped': return 'bg-blue-100 text-blue-700'
      default: return 'bg-gray-100 text-gray-700'
    }
  }

  if (loading) {
    return (
      <ProtectedRoute requireRole={true}>
        <div className="min-h-screen py-20 container mx-auto px-4">
          <TableSkeleton />
        </div>
      </ProtectedRoute>
    )
  }

  return (
    <ProtectedRoute requireRole={true}>
      <div className="min-h-screen py-20 container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-4xl font-bold mb-8 text-gray-900 dark:text-white">Order History</h1>

        {showSuccess && transactionId && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-4 bg-green-100 dark:bg-green-900 border border-green-400 dark:border-green-600 text-green-700 dark:text-green-300 rounded-lg flex items-center gap-3"
            role="alert"
          >
            <FaCheckCircle className="text-2xl" />
            <div>
              <p className="font-bold text-lg">Order placed successfully!</p>
              <p className="text-sm">Transaction ID: {transactionId}</p>
            </div>
          </motion.div>
        )}

          {orders.length === 0 ? (
            <div className="card text-center py-12">
              <p className="text-gray-600">No orders yet.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="card"
                >
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-bold">Order #{order.id}</h3>
                      <p className="text-sm text-gray-500">
                        Placed on {new Date(order.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(order.status)}`}>
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </span>
                  </div>
                  <div className="mb-4">
                    {Array.isArray(order.items) && order.items.map((item: any, idx: number) => (
                      <div key={idx} className="flex justify-between py-2 border-b">
                        <span>{item.name} x {item.quantity}</span>
                        <span>₹{item.price * item.quantity}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Total Amount</span>
                    <span className="text-2xl font-bold text-primary-600">₹{order.total}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </ProtectedRoute>
  )
}

