'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { FaEnvelope, FaPhone, FaMapMarkerAlt } from 'react-icons/fa'

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log('Contact form submitted:', formData)
    setSubmitted(true)
    setFormData({ name: '', email: '', message: '' })
    setTimeout(() => setSubmitted(false), 3000)
  }

  return (
    <div className="min-h-screen py-20 container mx-auto px-4" role="main">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-2xl mx-auto"
      >
        <h1 className="text-4xl md:text-6xl font-bold mb-12 text-center text-gray-900 dark:text-white">
          Contact Us
        </h1>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="card bg-white dark:bg-gray-800"
        >
          {submitted && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mb-6 p-4 bg-green-100 dark:bg-green-900 border border-green-400 dark:border-green-600 text-green-700 dark:text-green-300 rounded-lg text-lg"
              role="alert"
            >
              Thank you for your message! We will get back to you soon.
            </motion.div>
          )}
          <form onSubmit={handleSubmit} className="space-y-6" role="form" aria-label="Contact form">
            <div>
              <label htmlFor="name" className="block text-lg font-semibold mb-2 text-gray-900 dark:text-white">
                Name
              </label>
              <input
                type="text"
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-3 text-lg border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-4 focus:ring-primary-500/50 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                required
                aria-required="true"
                aria-label="Your name"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-lg font-semibold mb-2 text-gray-900 dark:text-white">
                Email
              </label>
              <input
                type="email"
                id="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 text-lg border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-4 focus:ring-primary-500/50 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                required
                aria-required="true"
                aria-label="Your email address"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-lg font-semibold mb-2 text-gray-900 dark:text-white">
                Message
              </label>
              <textarea
                id="message"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                rows={6}
                className="w-full px-4 py-3 text-lg border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-4 focus:ring-primary-500/50 focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white resize-none"
                required
                aria-required="true"
                aria-label="Your message"
              />
            </div>
            <button 
              type="submit" 
              className="btn-primary w-full text-lg py-4"
              aria-label="Send message"
            >
              Send Message
            </button>
          </form>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="mt-12 grid md:grid-cols-3 gap-6"
        >
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="card bg-white dark:bg-gray-800 text-center hover:shadow-2xl transition-shadow"
          >
            <FaEnvelope className="text-4xl text-primary-600 dark:text-primary-400 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">Email</h3>
            <p className="text-gray-600 dark:text-gray-300 text-lg">contact@empowerher.com</p>
          </motion.div>
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="card bg-white dark:bg-gray-800 text-center hover:shadow-2xl transition-shadow"
          >
            <FaPhone className="text-4xl text-primary-600 dark:text-primary-400 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">Phone</h3>
            <p className="text-gray-600 dark:text-gray-300 text-lg">+91 9876543210</p>
          </motion.div>
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="card bg-white dark:bg-gray-800 text-center hover:shadow-2xl transition-shadow"
          >
            <FaMapMarkerAlt className="text-4xl text-primary-600 dark:text-primary-400 mx-auto mb-4" />
            <h3 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">Address</h3>
            <p className="text-gray-600 dark:text-gray-300 text-lg">Rampur, Uttar Pradesh, India</p>
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  )
}


