'use client'

import { useEffect, useState } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { isAuthenticated, hasRole, getCurrentUser, getDashboardPath } from '@/utils/auth'
import LoadingSplash from './LoadingSplash'

interface ProtectedRouteProps {
  children: React.ReactNode
  requireRole?: boolean
}

export default function ProtectedRoute({ children, requireRole = false }: ProtectedRouteProps) {
  const router = useRouter()
  const pathname = usePathname()
  const [loading, setLoading] = useState(true)
  const [authorized, setAuthorized] = useState(false)

  useEffect(() => {
    const checkAuth = () => {
      const authenticated = isAuthenticated()
      
      if (!authenticated) {
        router.push('/login')
        return
      }

      if (requireRole) {
        const userHasRole = hasRole()
        if (!userHasRole) {
          router.push('/role-select')
          return
        }

        // Check if user has access to this route based on role
        const user = getCurrentUser()
        if (user?.role) {
          const userRole = user.role.toLowerCase()
          
          // Check role-based route access
          if (pathname.startsWith('/girls') && userRole !== 'girl') {
            router.push(getDashboardPath(userRole))
            return
          }
          if (pathname.startsWith('/women') && userRole !== 'woman') {
            router.push(getDashboardPath(userRole))
            return
          }
          if (pathname.startsWith('/customer') && userRole !== 'customer') {
            router.push(getDashboardPath(userRole))
            return
          }
          if (pathname.startsWith('/admin') && userRole !== 'admin') {
            router.push(getDashboardPath(userRole))
            return
          }
          if (pathname.startsWith('/fieldagent') && userRole !== 'fieldagent') {
            router.push(getDashboardPath(userRole))
            return
          }
        }
      }

      setAuthorized(true)
      setLoading(false)
    }

    checkAuth()
  }, [router, pathname, requireRole])

  if (loading) {
    return <LoadingSplash />
  }

  if (!authorized) {
    return null
  }

  return <>{children}</>
}

