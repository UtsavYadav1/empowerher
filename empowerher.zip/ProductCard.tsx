'use client'

import { motion } from 'framer-motion'
import { useState } from 'react'

interface ProductCardProps {
  product: {
    id: number
    name: string
    description: string
    price: number
    imageUrl?: string
  }
  showAddToCart?: boolean
}

export default function ProductCard({ product, showAddToCart = true }: ProductCardProps) {
  const [added, setAdded] = useState(false)

  const handleAddToCart = () => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]')
    const existingItem = cart.find((item: any) => item.id === product.id)
    
    if (existingItem) {
      existingItem.quantity += 1
    } else {
      cart.push({ ...product, quantity: 1 })
    }
    
    localStorage.setItem('cart', JSON.stringify(cart))
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  return (
    <div className="card hover:shadow-xl transition-shadow overflow-hidden">
      <div className="h-48 bg-gradient-to-br from-primary-200 to-primary-400 flex items-center justify-center mb-4">
        <span className="text-6xl">🛍️</span>
      </div>
      <h3 className="text-xl font-bold mb-2">{product.name}</h3>
      <p className="text-gray-600 text-sm mb-4 line-clamp-2">{product.description}</p>
      <div className="flex justify-between items-center">
        <span className="text-2xl font-bold text-primary-600">₹{product.price}</span>
        {showAddToCart && (
          <button 
            onClick={handleAddToCart}
            className={`text-sm px-4 py-2 rounded-lg font-semibold transition-colors ${
              added 
                ? 'bg-green-600 text-white' 
                : 'bg-primary-600 text-white hover:bg-primary-700'
            }`}
          >
            {added ? 'Added!' : 'Add to Cart'}
          </button>
        )}
      </div>
    </div>
  )
}

