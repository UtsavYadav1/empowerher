import { NextRequest, NextResponse } from 'next/server'

// Mock tutorials data
let tutorials = [
  {
    id: 1,
    title: 'How to Start Your Online Business',
    description: 'Learn the basics of starting an online business from scratch',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '15:30',
    category: 'business',
    watched: false,
  },
  {
    id: 2,
    title: 'Digital Marketing Basics',
    description: 'Introduction to digital marketing strategies for small businesses',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '20:45',
    category: 'marketing',
    watched: false,
  },
  {
    id: 3,
    title: 'Financial Planning for Entrepreneurs',
    description: 'Essential financial planning tips for women entrepreneurs',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    duration: '18:20',
    category: 'finance',
    watched: false,
  },
]

// GET - List all tutorials
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const category = searchParams.get('category')

    let filteredTutorials = tutorials
    if (category) {
      filteredTutorials = tutorials.filter(t => t.category === category)
    }

    return NextResponse.json({
      success: true,
      data: filteredTutorials,
      count: filteredTutorials.length,
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to fetch tutorials' },
      { status: 500 }
    )
  }
}

// PATCH - Mark tutorial as watched
export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { tutorialId, watched } = body

    if (tutorialId === undefined || watched === undefined) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const tutorial = tutorials.find(t => t.id === parseInt(tutorialId))
    if (!tutorial) {
      return NextResponse.json(
        { success: false, error: 'Tutorial not found' },
        { status: 404 }
      )
    }

    tutorial.watched = watched

    return NextResponse.json({
      success: true,
      data: tutorial,
    })
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to update tutorial' },
      { status: 500 }
    )
  }
}

